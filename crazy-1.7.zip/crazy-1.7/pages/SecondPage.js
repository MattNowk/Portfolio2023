import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import ParametersButton from '../components/ParametersButton';
import Wheel from '../components/Wheel';

export default function SecondPage() {
  const [modalVisible, setModalVisible] = useState(false);
  
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <View style={styles.container}>
        <ParametersButton hitSlop={{ top: 100, bottom: 100, left: 100, right: 100 }} modalVisible={modalVisible} setModalVisible={setModalVisible} />
      </View>
      <Wheel />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 10,
    right: 10,
  },
});
