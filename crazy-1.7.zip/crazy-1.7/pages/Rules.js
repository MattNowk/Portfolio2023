import React, { useState, useEffect, useRef } from 'react';
import Swiper from 'react-native-swiper';
import { StyleSheet, Text, View, Image, AppRegistry, ImageBackground } from 'react-native';
import ParametersButton from '../components/ParametersButton';
import CloseButton from '../components/CloseButton';
import componentsStyles from '../assets/componentsStyles';
import pagesStyles from '../assets/pagesStyles';
import globalStyles from '../assets/globalStyles';
import { TouchableOpacity } from 'react-native';
import Confetti from 'react-native-confetti';
import { useNavigation } from '@react-navigation/native';
import Game from './Game';
import Playbutton from '../components/Playbutton';

export default function Rules({ navigation }) {
  const [confettiInterval, setConfettiInterval] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const confettiViewRef = useRef(null);

  useEffect(() => {
    startConfetti();
    setConfettiInterval(
      setInterval(() => {
        startConfetti();
      }, 1500000)
    );

    return () => {
      clearInterval(confettiInterval);
    };
  }, []);

  function startConfetti() {
    if (confettiViewRef.current) {
      confettiViewRef.current.startConfetti();
    }
  }

  return (
    <Swiper
      style={styles.wrapper}
      loop={false}
      
    >

        <View style={styles.slide1}>
        
        
        <ParametersButton modalVisible={modalVisible} setModalVisible={setModalVisible} />
          {modalVisible && <View style={pagesStyles.containerBlur}></View>}
            <Image style={styles.crazyTeacherRules1} source={require('../assets/images/CrazyTeacherRules1.png')} />
            <Image style={styles.bubbleRules1} source={require('../assets/images/bubbleRules1.png')} />
            <Text style={styles.bubbleTextRules1}><Text style={styles.redTextRules}>Bienvenue</Text> dans {"\n"} le <Text style={styles.blueTextRules}>tutoriel</Text> !</Text>
            
          </View>

          <View style={styles.slide2}>
              
          <ParametersButton modalVisible={modalVisible} setModalVisible={setModalVisible} />
          {modalVisible && <View style={pagesStyles.containerBlur}></View>}
              <Image style={styles.plageCrazyRules2} source={require('../assets/images/plageCrazyRules2.png')} />
              <Image style={styles.yellowCircleRules2} source={require('../assets/images/yellowCircleRules2.png')} />
              <Image style={styles.bubbleRules2} source={require('../assets/images/bubbleRules2.png')} />
              <Text style={styles.bubbleTextRules2}>Commences par {"\n"} poser le telephone {"\n"} au <Text style={styles.blueTextRules}>milieu</Text> des {"\n"} joueurs</Text>
          </View>

          <View style={styles.slide3}>
              
          <ParametersButton modalVisible={modalVisible} setModalVisible={setModalVisible} />
          {modalVisible && <View style={pagesStyles.containerBlur}></View>}
              <Image style={styles.plageCrazyRules2} source={require('../assets/images/extraRules3.png')} />
              <Image style={styles.bubbleRules3} source={require('../assets/images/bubbleRules3.png')} />
              <Text style={styles.bubbleTextRules3}>Le but sera de {"\n"} trouver un <Text style={styles.redTextRules}>MOT</Text> {"\n"} correspondant au {"\n"} <Text style={styles.blueTextRules}>THEME</Text>  et {"\n"} commencant par la  {"\n"} <Text style={styles.redTextRules}>LETTRE </Text> affichée !</Text>
          </View>

          <View style={styles.slide4}>
              
          <ParametersButton modalVisible={modalVisible} setModalVisible={setModalVisible} />
          {modalVisible && <View style={pagesStyles.containerBlur}></View>}
              <Image style={styles.colorExempleRules4} source={require('../assets/images/colorExempleRules4.png')} />
              <Text style={styles.TextRules4}>Un thème : <Text style={styles.blueTextRules}>Les vacances</Text></Text>
              <Text style={styles.imageTextRules4}>Une image :</Text>
              <Image style={styles.imageTextatRules4} source={require('../assets/images/Group.png')} />
              <Text style={styles.secondTextRules4}>Une lettre : </Text>
              <Image style={styles.imageTextatRules5} source={require('../assets/images/letterTRules4.png')} />
              <Text style={styles.secondTextRules4}>Réponse : <Text style={styles.yellowTextRules}>    Un Transat</Text></Text>
          </View>

          <View style={styles.slide5}>
              
          <ParametersButton modalVisible={modalVisible} setModalVisible={setModalVisible} />
          {modalVisible && <View style={pagesStyles.containerBlur}></View>} 
              <Image style={styles.backgroundRules5} source={require('../assets/images/backgroundRules5.png')} />
              <Image style={styles.bubbleRules5} source={require('../assets/images/bubbleRules5.png')} />
              <Text style={styles.bubbleTextRules5}>Comptes tes points {"\n"} avec tes <Text style={styles.yellowTextRules}>DOIGTS !</Text></Text>
              <Text style={styles.secondBubbleTextRules5}>Le <Text style={styles.redTextRules}>PREMIER</Text> qui {"\n"}trouve un mot gagne {"\n"}<Text style={styles.redTextRules}>2</Text> points {"\n"}{"\n"}Le <Text style={styles.blueTextRules}>DEUXIEME</Text> gagne {"\n"} <Text style={styles.blueTextRules}>1</Text> point {"\n"}{"\n"}Et les autres ne {"\n"}gagnent <Text style={styles.yellowTextRules}>RIEN</Text> !</Text>
          </View>

          <View style={styles.slide6}>
              
          <ParametersButton modalVisible={modalVisible} setModalVisible={setModalVisible} />
          {modalVisible && <View style={pagesStyles.containerBlur}></View>}
              <Image style={styles.jurrasicRules6} source={require('../assets/images/jurrasicRules6bis.png')} />
              <Image style={styles.bubbleRules6} source={require('../assets/images/bubbleRules6.png')} />
              <Text style={styles.bubbleTextRules6}>Dès qu’un joueur a {"\n"}<Text style={styles.redTextRules}>5 POINTS</Text>, il peux {"\n"}donner un <Text style={styles.blueTextRules}>gage</Text> à{"\n"} qui il veut grâce à{"\n"} la <Text style={styles.redTextRules}>roue des gages</Text> !</Text>
          </View>

          <View style={styles.slide7}>
              
          <ParametersButton modalVisible={modalVisible} setModalVisible={setModalVisible} />
          {modalVisible && <View style={pagesStyles.containerBlur}></View>}
              <Image style={styles.backgroundRules7} source={require('../assets/images/backgroundRules7.png')} />
              <Image style={styles.bubbleRules7} source={require('../assets/images/bubbleRules7.png')} />
              <Text style={styles.bubbleTextRules7}>5 type de gages :</Text>
              <Text style={styles.secondBubbleTextRules7}><Text style={styles.redTextRules}>Action</Text> {"\n"}<Text style={styles.blueTextRules}>Vérité</Text> {"\n"}<Text style={styles.yellowTextRules}>Switch</Text> {"\n"}<Text style={styles.redTextRules}>Kiss</Text> {"\n"}<Text style={styles.blueTextRules}>No limit</Text></Text>
          </View>

          <View style={styles.slide8}>
        <Confetti ref={confettiViewRef} />
        
        <ParametersButton modalVisible={modalVisible} setModalVisible={setModalVisible} />
          {modalVisible && <View style={pagesStyles.containerBlur}></View>}
              <Image style={styles.backgroundRules7} source={require('../assets/images/mexicanRules8.png')} />
              <Image style={styles.bubbleRules8} source={require('../assets/images/bubbleRules8.png')} />
              <Text style={styles.bubbleTextRules8}><Text style={styles.redTextRules}>Félicitations</Text> tu es{"\n"} maintenant prêt à{"\n"} <Text style={styles.blueTextRules}>jouer</Text> !</Text>
              <View style={styles.containerPlayButton}>
              <Playbutton navigation={navigation} /></View>

              </View>
    </Swiper>
  );
}



const styles = StyleSheet.create({
  wrapper: {},
  slide1: {
    flex: 1,
    position: 'relative',
    backgroundColor: '#B5E9FA',
  },
  slide2: {
    flex: 1,
    backgroundColor: '#89BAE7',
    position: 'relative',
  },
  slide3: {
    flex: 1,
    backgroundColor: '#C6D5DA',
    position: 'relative',
  },
  slide4: {
    flex: 1,
    backgroundColor: '#3289D9',
    position: 'relative',
  },
  slide5: {
    flex: 1,
    backgroundColor: '#fff',
    position: 'relative',
  },
  slide6: {
    flex: 1,
    backgroundColor: '#fff',
    position: 'relative',
  },
  slide7: {
    flex: 1,
    backgroundColor: '#E0FFF9',
    position: 'relative',
  },
  slide8: {
    flex: 1,
    backgroundColor: '#E0FFF9',
    position: 'relative',
  },
  text: {
    color: '#fff',
    fontSize: 30,
  },
  // Page 1 of Rules
  crazyTeacherRules1: {
  position: 'absolute',
  bottom: 0,
  height: '100%',
  width: '100%',
  zIndex:-10,
  },
  yellowCircleRules1:{
    marginRight: 0,
    marginLeft:"auto",
  },
  bubbleRules1:{
    position: 'absolute',
    top: 200,
    marginLeft: "15%",
    marginRight: "15%",
  },
  bubbleTextRules1:{
    textAlign: 'center',
    fontStyle: 'italic',
    fontSize: 35,
    position: 'absolute',
    top: 270,
    marginLeft: "18%",
    marginRight: "15%",
    transform: [{ rotate: '5deg'}],
    fontWeight: '900',
  },

  backgroundRules1:{
    width: '100%',
    height: '100%',
  },
  // Page 2 of Rules
  plageCrazyRules2: {
    position: 'absolute',
    zIndex:-10,
    bottom: 0,
    right:0,
    width: '100%',
    height: '100%',
  },
  yellowCircleRules2:{
    position: 'absolute',

  },
  bubbleRules2:{
    position: 'absolute',
    top: 300,
    marginLeft: "10%",
    marginRight: "15%",
  },
  bubbleTextRules2:{
    textAlign: 'center',
    fontStyle: 'italic',
    fontSize: 29,
    position: 'absolute',
    top: 330,
    left: 56,
    transform: [{ rotate: '6.1deg'}],
    fontWeight:'900',
  },
  // Page 3 of Rules
  bubbleRules3:{
    position: 'absolute',
    top: 240,
    left: 50,
  },
  bubbleTextRules3:{
    textAlign: 'center',
    fontStyle: 'italic',
    fontSize: 29,
    position: 'absolute',
    top: 265,
    left: 56,
    transform: [{ rotate: '-1deg'}],
    fontWeight:'900',
  },
  redTextRules:{
    color:'#FF0000',
  },
  blueTextRules:{
    color:'#18D5FF',
  },
  yellowTextRules:{
    color:'#FFE600',
  },

  // Page 4 of Rules

  colorExempleRules4:{
    width: '100%',
    height: '100%',
    position: 'absolute',
    bottom: 0,
  },
  TextRules4:{
    fontSize: 32,
    textAlign: 'center',
    marginTop: 222,
    color: 'white',
    fontWeight:'bold',
  },
  imageTextRules4:{
    position: 'relative',
    fontSize: 32,
    marginLeft: 20,
    marginTop: 25,
    color: 'white',
    fontWeight:'bold',
  },
  imageTextatRules4:{
    position: 'absolute',
    right:80,
    top:265,
    height:'9%',
    width:'18%',
  },
  secondTextRules4:{
    fontSize: 32,
    marginLeft: 20,
    marginTop: 25,
    color: 'white',
    fontWeight:'bold',
  },
  imageTextatRules5:{
    position: 'absolute',
    right:80,
    bottom:395,
    height:'10%',
    width:'18%',

  },
  // Page5 of Rules
  backgroundRules5:{
    position: 'absolute',
    bottom:0,
    width: '100%',
    height: '100%',
    zIndex: -1,
  },
  bubbleRules5:{
  position: 'absolute',
   top:70,
   left:30,
  },
  bubbleTextRules5:{
    fontSize: 28,
    position: 'absolute',
    top:105,
    left:48,
    transform: [{ rotate: '-0.6deg'}],
    fontWeight:'900',
  },
  secondBubbleTextRules5:{
    position: 'absolute',
    top:255,
    left:100 ,
    fontSize: 28,
    textAlign: 'center',
    transform: [{ rotate: '-0.4deg'}],
    fontWeight:'900',
  },
  // Page 6 of Rules
  jurrasicRules6:{
    position: 'absolute',
    bottom: 0,
    width: '100%',
    height:'100%',
    zIndex:-1,
  },
  bubbleRules6:{
    position: 'absolute',
    top: 235,
    left:50,
  },
  bubbleTextRules6:{
    textAlign: 'center',
    fontStyle: 'italic',
    fontSize: 28,
    marginTop: 270,
    transform: [{ rotate: '-1deg'}],
    fontWeight:'900',
    marginLeft:20,
  },
  // Page 7 of Rules
  backgroundRules7:{
    position: 'absolute',
    bottom:0,
    width: '100%',
    height: '100%',
    zIndex:-10,
  },
  bubbleRules7:{
    position: 'absolute',
    top: 320,
    left:50,
  },
  bubbleTextRules7:{
    textAlign: 'center',
    fontSize: 28,
    marginTop: 340,
    fontWeight:'900',
  },
  secondBubbleTextRules7:{
    position: 'absolute',
    top:378,
    left:160,
    fontSize: 28,
    fontWeight:'900',
  },
  // Page 8 of Rules
  bubbleRules8:{
    position: 'absolute',
    top: 118,
    right: 42,
  },
  bubbleTextRules8:{
    textAlign: 'center',
    fontSize: 32,
    marginTop: 150,
    transform: [{ rotate: '-0.5deg'}],
    fontWeight:'900',
    marginRight: 18,
  },
  containerPlayButton:{
    position: 'absolute',
    top: 350,
    left:32,
  },
  
  redShapeButton:{
    width: 380,
    height:140,
  }
})

AppRegistry.registerComponent('crazy', () => SwiperComponent)