import React from 'react';
import { Image, View, TouchableOpacity } from 'react-native';
import Playbutton from '../components/Playbutton';
import CustomShapes from '../components/CustomShapes';
import componentsStyles from '../assets/componentsStyles';
import { useNavigation } from '@react-navigation/native';
import Rules from './Rules';

export default function Home({navigation: nav}) {
    const navigation = useNavigation();
    return (
        <View style={componentsStyles.start}>
            <View>
                <TouchableOpacity hitSlop={{ top: 100, bottom: 100, left: 100, right: 100 }} onPress={() => {
                    nav.navigate('Rules');
                  }}>
            <Image style={componentsStyles.rulesStart} source={require('../assets/images/rulesStart.png')} />
                </TouchableOpacity>
                <CustomShapes /> 
                <Playbutton navigation={navigation}/>
            </View>
        </View>
    )
}