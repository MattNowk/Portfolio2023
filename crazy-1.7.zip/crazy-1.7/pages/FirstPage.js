import React, { useEffect } from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import CustomShapes from '../components/CustomShapes';
import LoadingBar from '../components/LoadingBar';
import componentsStyles from '../assets/componentsStyles';
import Home from './Home';

export default function FirstPage({ navigation }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.navigate('Home');
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <View>
      <LoadingBar />
      <CustomShapes /> 
      <Image
  source={require('../assets/images/Logo.png')}
  style={{
    position: 'absolute',
    top: 270,
    left: 60,
  }}
/>
  </View>
  );
}

