import React, { useState } from 'react';
import { Image, TouchableOpacity, View } from 'react-native'
import RandomGenerator from '../components/RandomGenerator';
import Footer from '../components/Footer';
import ParametersButton from "../components/ParametersButton";
import pagesStyles from '../assets/pagesStyles';
import componentsStyles from '../assets/componentsStyles';
import { useNavigation } from '@react-navigation/native';

export default function Game({ navigation: nav }) {
    const [modalVisible, setModalVisible] = useState(false);
    const navigation = useNavigation();
    return (
      <View>
        <View>
          <TouchableOpacity activeOpacity={0.7} hitSlop={{ top: 60, bottom: 60, left: 60, right: 60 }} onPress={() => navigation.navigate('SecondPage')}>
            <Image style={componentsStyles.wheelIcon} source={require('../assets/images/wheelIcon.png')} />
          </TouchableOpacity>
          <ParametersButton hitSlop={{ top: 100, bottom: 100, left: 100, right: 100 }} modalVisible={modalVisible} setModalVisible={setModalVisible} />
          {modalVisible && <View style={pagesStyles.containerBlur}></View>}
          <RandomGenerator navigation={navigation} />
          <Footer />
        </View>
      </View>
    );
}
