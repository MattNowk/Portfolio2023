import React from 'react';
import { View, Text }  from 'react-native'
import componentsStyles from '../assets/componentsStyles'
import globalStyles from '../assets/globalStyles'


export default class Footer extends React.Component {
    render() {
        return <>
            <View style={componentsStyles.bgFooter}>
                <Text style={[componentsStyles.textFooter, globalStyles.primaryFont, componentsStyles.textTitleFooter]}>5 points gagnés =</Text>
                <Text style={[componentsStyles.textFooter, globalStyles.primaryFont]}>tu donnes un gage à qui tu veux</Text>
            </View>
        </>
    }
}