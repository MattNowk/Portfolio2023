import React from 'react'
import {Text, View, ImageBackground, TouchableOpacity} from 'react-native'
import image from '../assets/images/shapeButtonHome.png'
import componentsStyles from '../assets/componentsStyles'
import globalStyles from '../assets/globalStyles'

export default function Playbutton({navigation}) {

        return <>
            <View style={componentsStyles.container}>
                <ImageBackground style={componentsStyles.bgImg} resizeMode="cover" source={image}>
                    <TouchableOpacity style={componentsStyles.button} onPress={() => navigation.navigate('Game')}>
                        <Text style={[componentsStyles.text, globalStyles.secondaryFont]}>Jouer</Text>
                    </TouchableOpacity>
                </ImageBackground>
            </View>
        </>
}