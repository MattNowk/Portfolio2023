import React, { useState } from 'react';
import { View, Text, Modal, Image, TouchableOpacity, StyleSheet, SafeAreaView } from 'react-native';
import componentsStyles from '../assets/componentsStyles';
import globalStyles from '../assets/globalStyles';

const PremiumModal = (props) => {
  const [modalVisible, setModalVisible] = useState(false);

  const toggleModal = () => {
    setModalVisible(!modalVisible);
  };

  return (
    <View>
      
           <TouchableOpacity onPress={toggleModal} activeOpacity={0.7} style={styles.premiumButton}>
                <Image style={componentsStyles.logoPremium} source={require('../assets/images/logopremium.png')} />
                <Text style={[componentsStyles.modalText, componentsStyles.modalTextPremium, globalStyles.primaryFontBold]}>DEVENIR PREMIUM!</Text>
              </TouchableOpacity>

      <Modal
        animationType="slide"
        transparent={false}
        visible={modalVisible}
        onRequestClose={() => {
          setModalVisible(false);
        }}
      >
        <SafeAreaView style={styles.modalContainer}>

          {/* Close modal button */}
          <TouchableOpacity onPress={toggleModal}>
          <Image style={styles.closeButton} source={require('../assets/images/closeButtonPremium.png')} />
          </TouchableOpacity>

          <Image style={styles.premiumCrazy} source={require('../assets/images/premiumCrazy.png')} />
          <Text style={styles.bePremiumTitle}>DEVENIR{"\n"}PREMIUM!</Text>
          <Text style={styles.bePremiumText}> Débloque tout le {"\n"}
          <Text style={styles.colorBluePremium}>contenu</Text> <Text style={styles.colorYellowPremium}>exclusif</Text> {"\n"}
                pour seulement {"\n"}
          <Text style={styles.colorBluePremium}>1,99€</Text> </Text> 
          <Image style={styles.premiumShapes} source={require('../assets/images/premiumShapes.png')} />
          <Image style={styles.logosPremium} source={require('../assets/images/3logosPremium.png')} />
          <Text style={[styles.colorTextPremium, styles.colorText1Premium]}>+ de 70 themes</Text>
          <Text style={[styles.colorTextPremium, styles.colorText2Premium]}>+ de 15 lettres</Text>
          <Text style={[styles.colorTextPremium, styles.colorText3Premium]}>+ la roue complète</Text>
          <TouchableOpacity activeOpacity={0.7} style={styles.buttonUnlockPremium}>
          <Text style={styles.buttonUnlockTextPremium}>DEBLOQUER</Text>
          </TouchableOpacity>
        </SafeAreaView>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    position: 'relative',
    backgroundColor:'rgba(31, 31, 31, 0.9)',
  },
  closeButton:{
    position: 'absolute',
    right: 10,
    top: 15,
    width: 65,
    height: 60,
  },
premiumButton: {
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'rgba(0, 0, 0, 0.22)',
      borderColor: '#fff',
      borderRadius: 15,
      borderWidth: 3,
      height:100,
      marginBottom: 30,
      width: 300,
   },
   bePremiumTitle:{
    fontSize: 48,
    fontStyle: 'italic',
    fontWeight: "900",
    color: '#F5C20B',
    shadowColor: 'rgba(255, 138, 0, 0.49)',
    shadowOffset: {
    width: 0,
    height: 4,
  },
    shadowRadius: 4,
    shadowOpacity: 1,
    marginLeft: 160,
    marginTop: 80,
   },
   premiumCrazy:{
    position: 'absolute',
    top: 30,
   },
   bePremiumText:{
    textAlign: 'center',
    color: 'white',
    fontWeight: "900",
    fontSize: 37,
    marginTop: 70,
    lineHeight: 47,
    fontStyle: 'italic',
    marginLeft: 22,
   },
   premiumShapes:{
    width: '100%',
    position: 'absolute',
    top:250,
   },
   colorBluePremium:{
    color:"#00AEEF",
   },
   colorYellowPremium:{
    color: '#F5C20B',
   },
   logosPremium:{
    marginLeft: 50,
    marginTop: 15,
   },
   colorTextPremium:{
    position: 'absolute',
    left: 110,
    color: '#F5C20B',
    shadowColor: 'rgba(255, 138, 0, 0.49)',
    fontSize: 27,
    fontStyle: 'italic',
    fontWeight: "900",
    shadowOffset: {
    width: 0,
    height: 4,
   }},
   colorText1Premium:{
    bottom: 288,
   },
   colorText2Premium:{
    bottom: 220,
   },
   colorText3Premium:{
    bottom: 150,
   },
   buttonUnlockPremium:{
    marginTop:40,
    borderWidth: 8,
    borderRadius: 25,
    width: '75%',
    borderColor: '#fff',
    marginLeft:"auto",
    marginRight:"auto",
   },
   buttonUnlockTextPremium:{
    color: 'white',
    fontSize: 40,
    fontWeight: "900",
    textAlign:'center',
    paddingTop:13,
    paddingBottom:13,
   }

});

export default PremiumModal;