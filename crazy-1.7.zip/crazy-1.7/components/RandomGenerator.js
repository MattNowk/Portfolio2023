import Themes from '../services/Themes'
import Letters from '../services/Letters'
import { View, Text, Image, TouchableOpacity } from 'react-native'
import componentsStyles from '../assets/componentsStyles'
import globalStyles from '../assets/globalStyles'
import nextbtn from '../assets/images/next-arrow.png'
import { useNavigation } from '@react-navigation/native'
import firstPlanShapeRed from '../assets/images/redThemeShape.png'
import firstPlanShapeYellow from '../assets/images/yellowThemeShape.png'
import firstPlanShapeBlue from '../assets/images/blueThemeShape.png'
import secondPlanShapeYellow from '../assets/images/SecondPlanYellow.png'
import secondPlanShapeBlue from '../assets/images/SecondPlanBlue.png'
import secondPlanShapeRed from '../assets/images/SecondPlanRed.png'
import shapeLetterRed from '../assets/images/shapeLetterRed.png'
import shapeLetterYellow from '../assets/images/shapeLetterYellow.png'
import shapeLetterBlue from '../assets/images/shapeLetterBlue.png'
import { StyleSheet } from 'react-native';
import React, { useState, useEffect } from 'react';
import * as Speech from 'expo-speech';



const soundOn = require('../assets/images/SoundOn.png');
const soundOff = require('../assets/images/SoundOff.png');

const RandomGenerator = () => {
  const [backgroundColor, setBackgroundColor] = useState('#18D5FF');
  const [shapeLetterImage, setShapeLetterImage] = useState(shapeLetterRed);
  const [secondPlanShapeImage, setSecondPlanShapeImage] = useState(secondPlanShapeRed);
  const [firstPlanShapeImage, setFirstPlanShapeImage] = useState(firstPlanShapeBlue);
  const [randomL, setRandomL] = useState(Letters[Math.floor(Math.random() * 4)]);
  const [randomT, setRandomT] = useState(Themes[Math.floor(Math.random() * 11)]);  
  const themeImage = randomT.image;
  const themeTitle = randomT.title;
  const URL = randomL;
  const URLI = randomL.image;
  const [isNextButtonDisabled, setIsNextButtonDisabled] = useState(false); // introduce state variable
  const [lastSpeechInstance, setLastSpeechInstance] = useState(null);
  const [isTTSMuted, setIsTTSMuted] = useState(false);


  const updateRandoms = () => {
    let newRandomL, newRandomT;
  
    do {
      newRandomL = Letters[Math.floor(Math.random() * 4)];
    } while (newRandomL.title === randomL.title);
    setRandomL(newRandomL);
  
    do {
      newRandomT = Themes[Math.floor(Math.random() * 11)];
    } while (newRandomT.title === randomT.title);
    setRandomT(newRandomT);
  };
  
  useEffect(() => {
    speakThemeTitle();
  }, [themeTitle]);
  
  useEffect(() => {
    speakLetterTitle();
  }, [randomL]);
  

  const speakLetterTitle = () => {
    if (isTTSMuted) return; // Ne parle pas si isTTSMuted est vrai
  
    const letterTitle = randomL.title;
    Speech.speak("En ... " + letterTitle, { language: "fr", voice: "fr-fr-x-frc-local" });
  };
  
  const changeBackgroundColor = () => {
    if (!isNextButtonDisabled) {
      setIsNextButtonDisabled(true);
      updateRandoms();
      setBackgroundColor((prevColor) => {
        switch(prevColor) {
          case '#18D5FF':
            setShapeLetterImage(shapeLetterYellow);
            setSecondPlanShapeImage(secondPlanShapeBlue);
            setFirstPlanShapeImage(firstPlanShapeYellow);
            return '#FF0000';
          case '#FF0000':
            setShapeLetterImage(shapeLetterBlue);
            setSecondPlanShapeImage(secondPlanShapeRed);
            setFirstPlanShapeImage(firstPlanShapeBlue);
            return '#FFE602';
          case '#FFE602':
            setShapeLetterImage(shapeLetterRed);
            setSecondPlanShapeImage(secondPlanShapeYellow);
            setFirstPlanShapeImage(firstPlanShapeRed);
            return '#18D5FF';
          default:
            setShapeLetterImage(shapeLetterRed);
            setSecondPlanShapeImage(secondPlanShapeYellow);
            setFirstPlanShapeImage(firstPlanShapeRed);
            return '#18D5FF';
        }
      });
      setTimeout(() => {
        setIsNextButtonDisabled(false);
      }, 2000);
    }
  };
  // Speech.getAvailableVoicesAsync().then(voices => console.log(voices));

  const speakThemeTitle = () => {
    if (isTTSMuted) return;
    switch (themeTitle) {
      case "Animal":
        Speech.speak("Un animal", { language: "fr", voice: "fr-fr-x-frc-local" });
        break;
      case "Geographie":
        Speech.speak("Géographie", { language: "fr", voice: "fr-fr-x-frc-local" });
        break;
        case "Camping":
          Speech.speak("Au camping", { language: "fr", voice: "fr-fr-x-frc-local" });
          break;
          case "Salon Abandonné":
            Speech.speak("Dans le salon abandonné", { language: "fr", voice: "fr-fr-x-frc-local" });
            break;
            case "Montagne":
              Speech.speak("A la montagne", { language: "fr", voice: "fr-fr-x-frc-local" });
              break;
              case "Vêtements":
                Speech.speak("Un vêtement", { language: "fr", voice: "fr-fr-x-frc-local" });
                break;
                case "Cinéma":
                  Speech.speak("Cinéma", { language: "fr", voice: "fr-fr-x-frc-local" });
                  break;
                  case "Instrument":
                    Speech.speak("Un instrument", { language: "fr", voice: "fr-fr-x-frc-local" });
                    break;
                    case "Fruits":
                      Speech.speak("Un fruit", { language: "fr", voice: "fr-fr-x-frc-local" });
                      break;
                      case "Cuisine":
                        Speech.speak("Dans la cuisine", { language: "fr", voice: "fr-fr-x-frc-local" });
                        break;
                        case "Sport":
                          Speech.speak("Un sport", { language: "fr", voice: "fr-fr-x-frc-local" });
                          break;
    }
  }


  const navigation = useNavigation();

  return (
    <View style={[componentsStyles.gameContainer, { backgroundColor }]}>
      <Text style={componentsStyles.themeTitle}>{themeTitle}</Text>
      <Image style={componentsStyles.themeImage} source={themeImage}></Image>
      <Image style={componentsStyles.secondPlanShape} source={secondPlanShapeImage}></Image>
      <Image style={componentsStyles.firstPlanShape} source={firstPlanShapeImage}></Image>
      <Image style={componentsStyles.letterShape} source={shapeLetterImage}></Image>
      <Image style={componentsStyles.letter} source={URLI}></Image>
      <TouchableOpacity
        style={[componentsStyles.buttonNext, { backgroundColor: backgroundColor }, isNextButtonDisabled && { opacity: 0.5 }]}
        onPress={changeBackgroundColor}
        disabled={isNextButtonDisabled} // disable button if it's currently disabled
      >
        <Image source={nextbtn}></Image>

        <View style={styles.muteTTSButtonContainer}>
        <TouchableOpacity
          onPress={() => setIsTTSMuted(!isTTSMuted)}
          style={styles.muteTTSButton}
        >
          <Image source={isTTSMuted ? soundOff : soundOn} style={styles.muteTTSButtonImage} />
        </TouchableOpacity>
      </View>
      </TouchableOpacity>
    </View>

    
    
  );
} 

const styles = StyleSheet.create({
  muteTTSButtonContainer: {
    position: 'absolute',
    bottom: 610, // Ajustez la position en fonction de vos préférences
    right: 280, // Ajustez la position en fonction de vos préférences
  },
  muteTTSButton: {
    width: 50, // Ajustez la taille en fonction de vos préférences
    height: 50, // Ajustez la taille en fonction de vos préférences
    justifyContent: 'center',
    alignItems: 'center',
  },
  muteTTSButtonImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
})

export default RandomGenerator;