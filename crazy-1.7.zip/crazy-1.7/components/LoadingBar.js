import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';

const LoadingBar = () => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      if (progress < 100) {
        setProgress(progress + 2);
      }
    }, 1);

    return () => clearInterval(interval);
  },[progress]);

  return (
    <View style={styles.container}>
      <View style={[styles.bar, { width: `${progress}%` }]}>
        <Text style={styles.text}>{progress}%</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: 310,
    height: 30,
    backgroundColor: '#ddd',
    borderRadius: 10,
    overflow: 'hidden',
    alignSelf: 'center',
    marginTop: 50,
    position: 'absolute',
    bottom: -200,
    zIndex: 1
  },
  bar: {
    height: '100%',
    backgroundColor: '#FF0000',
    borderRadius: 10,
    zIndex : 2
  },
  text: {
    position: 'absolute',
    alignSelf: 'center',
    marginTop: 1,
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
});

export default LoadingBar;
