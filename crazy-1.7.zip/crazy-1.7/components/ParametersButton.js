import React, { useState } from 'react';
import { View, TouchableOpacity, Image, Text, Modal } from 'react-native';
import DropDownPicker from 'react-native-dropdown-picker';
import componentsStyles from '../assets/componentsStyles';
import globalStyles from '../assets/globalStyles';
import PremiumModal from './PremiumModal';
import { useNavigation } from '@react-navigation/native';
import RandomGenerator from './RandomGenerator';


export default function ParametersButton({ modalVisible, setModalVisible, selectedLanguage, setSelectedLanguage }) {
  const [isOpen, setIsOpen] = useState(false);
  const [currentValue, setCurrentValue] = useState();
  const [premiumModalVisible, setPremiumModalVisible] = useState(false); // Ajoutez cette ligne

  const items = [
    { label: 'Français', value: 'fr', icon: () => <Image source={require('../assets/images/LanguageFranceFlag.png')} style={componentsStyles.flagsDropDown} />},
    { label: 'Anglais', value: 'en' , icon: () => <Image source={require('../assets/images/royaume-uni.png')} style={componentsStyles.flagsDropDown} />},
    { label: 'Allemand', value: 'al' , icon: () => <Image source={require('../assets/images/allemagne.png')} style={componentsStyles.flagsDropDown} />},
    { label: 'Espagnol', value: 'es' , icon: () => <Image source={require('../assets/images/espagne.png')} style={componentsStyles.flagsDropDown} />},
    { label: 'Italien', value: 'it' , icon: () => <Image source={require('../assets/images/italy.png')} style={componentsStyles.flagsDropDown} />},
    { label: 'Portugais', value: 'pt' , icon: () => <Image source={require('../assets/images/portugal.png')} style={componentsStyles.flagsDropDown} />},
    { label: 'Brésilien', value: 'br' , icon: () => <Image source={require('../assets/images/bresil.png')} style={componentsStyles.flagsDropDown} />},
   
  ];

  const navigation = useNavigation();

  return (
    <View style={componentsStyles.modalContainerParam}>
      <TouchableOpacity onPress={() => setModalVisible(true)}>
        <Image style={componentsStyles.parametersButton} source={require('../assets/images/ParametersButton.png')} />
      </TouchableOpacity>

      {modalVisible && (
        <View style={componentsStyles.centeredView}>
          
          <Modal
            animationType="slide"
            transparent={true}
            visible={modalVisible}
            onRequestClose={() => {
              setModalVisible(!modalVisible);
            }}
          >
            
            <View style={componentsStyles.centeredView}>
              
              <View style={componentsStyles.modalView}>
                
                 {/* Close BUTTON */}
                <TouchableOpacity activeOpacity={0.7} onPress={() => setModalVisible(false)} style={{ position: 'absolute', top: 0, right: 0 }}>
                    <Image style={componentsStyles.closeModalParam} source={require('../assets/images/CloseButton.png')} />
                </TouchableOpacity>

                 {/* Parameters TITLES */}
                <Text style={[componentsStyles.modalTitle1, globalStyles.primaryFontBold]}>CRAZY</Text>
                <Text style={[componentsStyles.modalTitle2, globalStyles.primaryFontBold]}>PARAMETRES</Text>
              

                {/* PREMIUM Button */}
                
              <PremiumModal modalVisible={premiumModalVisible} setModalVisible={setPremiumModalVisible} />

                {/* RULES of the game Button */}
                <TouchableOpacity
                  activeOpacity={0.7}
                  style={componentsStyles.buttonModalParam}
                  onPress={() => {
                    setModalVisible(false); // ferme le modal avant la navigation
                    navigation.navigate('Rules'); // navigue vers la page Rules
                  }}
                >
                  <Image style={componentsStyles.rulesLogo} source={require('../assets/images/RulesLogo.png')} />
                  <Text style={[componentsStyles.modalText, componentsStyles.modalTextRules]}>REGLES DU JEU</Text>
                </TouchableOpacity>

                {/* LANGUAGE Button */}
                <DropDownPicker
                  
                  defaultValue="fr"
                  activeOpacity={0.7}
                  value={currentValue}
                  style={[componentsStyles.buttonModalParam]}
                  items={items}
                  open={isOpen}
                  dropdownIconColor="white"
                  dropDownContainerStyle={{ width: '80%', backgroundColor: '#1C191F', borderColor: '#fff',borderWidth: 2, borderTopWidth: 0,}}
                  activeItemStyle={{backgroundColor: 'white'}}
                  setValue={(val) => setCurrentValue(val)}
                  setOpen={() => setIsOpen (!isOpen)}
                  onChangeItem={(item) => {
                    setSelectedLanguage(item.value);
                    setModalVisible(false);
                  }}
                  containerStyle={{ justifyContent: 'center', alignItems: 'center', }}
                  textStyle={[ componentsStyles.modalText,componentsStyles.modalTextLanguages]}
                  placeholder="CHANGER DE LANGUE" 
                  placeholderStyle={{ paddingLeft: 30 }}
                  
                  
                />

                {/* SHARING Button */}
                <TouchableOpacity activeOpacity={0.7} style={componentsStyles.buttonModalParam}>
                <Image style={componentsStyles.sharingArrow} source={require('../assets/images/SharingArrow.png')} />
                    <Text style={[componentsStyles.modalText, componentsStyles.modalTextSharing]}>
                        <Text style={{ color: '#ffffff' }}>PARTAGER</Text> 
                        <Text style={{ color: '#FFFF00', textShadowColor: 'rgba(255, 230, 2, 0.7)', }}> L'APPLICATION</Text>
                    </Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>
        </View>
      )}
    </View>
  );
}

