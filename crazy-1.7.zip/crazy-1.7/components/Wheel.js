import React, { useRef, useState } from 'react';
import { View, Image, StyleSheet, TouchableOpacity, Text, Dimensions } from 'react-native';
import WheelOfFortune from 'react-native-wheel-of-fortune/src';
import { Audio } from 'expo-av';
import { useNavigation } from '@react-navigation/native';

const playSound = async () => {
  const soundObject = new Audio.Sound();
  try {
    await soundObject.loadAsync(require('../assets/son/Wheel3.mp3'));
    await soundObject.playAsync();
  } catch (error) {
    console.log('Erreur lors de la lecture du son', error);
  }
};

const soundOn = require('../assets/images/SoundOn.png');
const soundOff = require('../assets/images/SoundOff.png');

const screenWidth = Dimensions.get('window').width;
const maxTextWidth = screenWidth * 0.6;


const Circle = ({color, style}) => (
  <View style={[styles.circle, style, {backgroundColor: color}]} />
);

const Wheel = () => {
  const wheelRef = useRef(null);
  const action = require('../assets/images/Action.png');
  const verite = require('../assets/images/Verite.png');
  const echange = require('../assets/images/echange.png');
  const cadenas = require('../assets/images/Cadenas.png');
  const PiedRoue = require('../assets/images/PiedRoue.png');
  
  const [winnerText, setWinnerText] = useState("???");
  const [buttonEnabled, setButtonEnabled] = useState(true);
  const [backToGameButtonEnabled, setBackToGameButtonEnabled] = useState(true);

  
  const participants = [
    { image: action, text: "Réalise l'action !", left: + 130, top: -10 },
    { image: verite, text: "Dis la vérité !", left: - 50, top: -420 },
    { image: echange, text: "La personne qui t'as désigné doit tourner la roue !", left: - 240, top: - 460 },
    { image: cadenas, text: "Débloquer la version premium", left: -130, top: -80 },
    { image: cadenas, text: "Débloquer la version premium", left: +90, top: +200 },
  ];

  const wheelOptions = {
    rewards: participants,
    knobSize: 25,
    borderWidth: 5,
    borderColor: '#000',
    innerRadius: 50,
    duration: 4000,
    backgroundColor: '#263238',
    textAngle: 'horizontal',
    knobSource: require('../assets/images/knoob.png'),
    getWinner: (value, index) => {
      const winnerText = value.text;
      if (index === 3 || index === 4) {
        // If the winner is participant 4 or 5, spin the wheel again
        wheelRef.current._tryAgain();
      } else {
        setWinnerText(winnerText);
      }
    },
    onRef: (ref) => {
      wheelRef.current = ref;
    },
  };
  
  const [isMuted, setIsMuted] = useState(false);

  const handlePress = () => {
    if (!buttonEnabled) return;
    setButtonEnabled(false);
    setBackToGameButtonEnabled(false); // désactiver le bouton "Retour au jeu"
    setTimeout(() => {
      setButtonEnabled(true);
      setBackToGameButtonEnabled(true); // réactiver le bouton "Retour au jeu" après 2 secondes (2000 ms)
    }, 4000);
  
    playSound();
    wheelRef.current._tryAgain();
  };
  
  const playSound = async () => {
    if (isMuted) return; // Ne joue pas le son si isMuted est true
  
    const soundObject = new Audio.Sound();
    try {
      await soundObject.loadAsync(require('../assets/son/Wheel3.mp3'));
      await soundObject.playAsync();
    } catch (error) {
      console.log('Erreur lors de la lecture du son', error);
    }
  };
  
  const navigation = useNavigation();


  return (
    <View style={styles.container}>
      <Circle color="#FF0000" style={styles.circleRed} />
      <Circle color="#18D5FF" style={styles.circleBlue} />
      <Circle color="#FFE602" style={styles.circleYellow} />
      <TouchableOpacity 
  onPress={handlePress}
  style={[styles.button, !buttonEnabled && styles.buttonDisabled]}
  disabled={!buttonEnabled}
>
  <Text style={styles.buttonText}>Tourner</Text>
</TouchableOpacity>

      <View style={styles.wheelContainer}>
        <WheelOfFortune wheelOptions={wheelOptions} options={wheelOptions} />
      </View>
      <View>
      {winnerText && (
  <View style={styles.winnerTextContainer}>
    <View style={styles.winnerBackground}></View>
    <Text
      style={styles.winnerText}
      numberOfLines={2}
      ellipsizeMode="tail"
      adjustsFontSizeToFit
      minimumFontScale={0.5}
    >
      {winnerText}
    </Text>
  </View>
)}

  </View>
  <View style={styles.container}>
      <Text style={styles.TexteGage}>Gage {"\n"} Tourne la Roue</Text>
      </View>

      <View style={styles.piedRoueContainer}>
      <Image source={PiedRoue} style={styles.piedRoue} />
      <Text style={styles.piedRoueText}></Text>
      <TouchableOpacity hitSlop={{ top: 60, bottom: 60, left: 60, right: 60 }}
      onPress={() => setIsMuted(!isMuted)}
      style={styles.muteButton}
      >
      <Image source={isMuted ? soundOff : soundOn} style={styles.muteButtonImage} />
      </TouchableOpacity>
      <TouchableOpacity
  style={[
    styles.backToGameButton,
    !backToGameButtonEnabled && styles.buttonDisabled,
  ]}
  onPress={() => navigation.navigate('Game')}
  disabled={!backToGameButtonEnabled}
>
  <Text style={styles.backToGameButtonText}>Retour au jeu</Text>
</TouchableOpacity>
    </View>
    </View>
  );  
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  TexteGage: {
    fontFamily: 'Montserrat',
    fontSize: 40,
    position: 'absolute',
    top: -480,
    fontWeight: 'bold',
    color: '#1E1E1E',
    zIndex: 20,
    textAlign: 'center',
  },
  circle: {
    position: 'absolute',
    width: 600,
    height: 586,
    borderRadius: 500,
  },
  circleRed: {
    top: -100,
    left: -450,
    zIndex: 1,
  },
  circleBlue: {
    top: 600,
    left: -400,
    zIndex: 2,
  },
  circleYellow: {
    top: 100,
    left: -300,
    zIndex: 0,
  },
  button: {
    zIndex: 1,
    backgroundColor: "transparent",
    borderRadius: 0,
    borderWidth: 0,
    borderColor: "#000000",
    paddingTop: 400,
    zIndex: 4,
  },
  buttonDisabled: {
    opacity: 0.5,
  },  
  buttonText: {
    fontSize: 20,
    color: "#FFFFFF",
    textAlign: "center",
    zIndex: 4,
    paddingBottom: 135,
    fontWeight: "bold",
    fontFamily: 'Montserrat',
  },
  wheelContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    zIndex: 3,
    paddingBottom: 50,
  },
  winnerTextContainer: {
    position: 'absolute',
    top: 130,
    left: '50%',
    transform: [{ translateX: -50 }, { translateY: -50 }],
    zIndex: 6,
  },  
  winnerBackground: {
    position: 'absolute',
    width: 300,
    height: 80,
    backgroundColor: '#000',
    borderRadius: 10,
    borderWidth: 5,
    borderColor: '#FFF',
    top: 30,
    left: -180,
    transform: [{ translateX: -125 }, { translateY: -40 }],
  },  
  winnerText: {
    position: 'absolute',
    fontSize: 20,
    fontWeight: 'bold',
    color: '#FFF',
    textAlign: 'center',
    zIndex: 7,
    top: 50,
    left: -150,
    transform: [{ translateX: -125 }, { translateY: -40 }],
    width: 250,
    fontFamily: 'Montserrat',
  },  
  piedRoueContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    zIndex: 2,
    top: 510,
  },
  piedRoue: {
    width: 150,
    height: 150,
  },
  piedRoueText: {
    color: '#FFF',
    marginTop: 10,
  },
  muteButtonImage: {
    width: 50,
    height: 50,
    position: 'absolute',
    bottom: 590,
    right: 120,
    zIndex: 6,
  },
  backToGameButton: {
    position: 'absolute',
    backgroundColor: '#000',
    paddingHorizontal: 5,
    paddingVertical: 10,
    borderRadius: 10,
    top: 250,
    zIndex: 10,
  },
  backToGameButtonText: {
    color: '#fff',
    fontSize: 20,
    fontFamily: 'Montserrat',
  },
});

export default Wheel;