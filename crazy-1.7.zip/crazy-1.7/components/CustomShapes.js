import componentsStyles from '../assets/componentsStyles';
import React from 'react';
import { View, Text, Image } from 'react-native'
import globalStyles from '../assets/globalStyles';

export default class CustomShapes extends React.Component {
    render() {
        return <>
            <View>
                <Text style={[globalStyles.primaryColor, componentsStyles.circleTopRight]}></Text>
                <Image style={componentsStyles.circleBottomLeft} source={require('../assets/images/shapeHomeBottomLeft.png')}></Image>
                <Text style={[globalStyles.primaryColor, componentsStyles.circleBottomRight]}></Text>
                <Image style={componentsStyles.cameleon} source={require('../assets/images/cameleon.png')}></Image>            
            </View>
        </>
    }
}
