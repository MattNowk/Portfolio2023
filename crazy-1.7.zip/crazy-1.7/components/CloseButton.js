import React, { Component } from 'react';
import { Image, View } from 'react-native';
import { TouchableOpacity} from 'react-native';
import componentsStyles from '../assets/componentsStyles';


export default class CloseButton extends Component {
  render() {
    return <>
        <View>
        <TouchableOpacity>
        <Image style={componentsStyles.closeButton} source={require('../assets/images/CloseButton.png')} />
       </TouchableOpacity>
       </View>
       
    </>
  }
}
