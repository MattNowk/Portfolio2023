const Themes = [
        { image: require('../assets/themes/Theme1.png'), title: 'Animal'},
        { image: require('../assets/themes/Theme3.png'), title: 'Camping'},
        { image: require('../assets/themes/Theme4.png'), title: 'Salon Abandonné'},
        { image: require('../assets/themes/Theme5.png'), title: 'Montagne'},
        { image: require('../assets/themes/Theme6.png'), title: 'Vêtements'},
        { image: require('../assets/themes/Theme7.png'), title: 'Cinéma'},
        { image: require('../assets/themes/Theme8.png'), title: 'Instrument'},
        { image: require('../assets/themes/Theme10.png'), title: 'Fruits'},
        { image: require('../assets/themes/Theme11.png'), title: 'Geographie'},
        { image: require('../assets/themes/Theme13.png'), title: 'Cuisine'},
        { image: require('../assets/themes/Theme14.png'), title: 'Sport'},
        { image: require('../assets/themes/Theme15.png'), title: 'Boisson'}
    ]

export default Themes;