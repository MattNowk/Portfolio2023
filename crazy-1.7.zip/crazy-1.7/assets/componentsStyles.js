import { StyleSheet } from "react-native";

const componentsStyles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    bgImg: {
        width: 330,
        height: 115
    },
    button: {
        paddingTop: 15,
    },
    text: {
        textAlign: 'center',
        fontSize: 76,
        color: '#FFF',
    },
    circleTopRight: {
        borderRadius: 300,
        position: 'absolute',
        top: -190,
        right: -80,
        width: 350,
        height: 370
    },
    circleBottomLeft: {
        width: 350,
        height: 360,
        top: 490,
        left: -60,
        transform: [{rotate: '-10deg'}]
    },
    circleBottomRight: {
        position: 'absolute',
        borderRadius: 200,
        right: -25,
        top: 720,
        width: 140,
        height: 140
    },
    cameleon: {
        width: 320,
        height: 450,
        position: 'absolute',
        top: 585,
        left: -120,
        zIndex: 2,
    },
    gameContainer: {
        width: '100%',
        height: '92.5%',
        position: 'relative',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        zIndex: -3
    },
    bgFooter: {
        backgroundColor: '#000',
        alignItems: 'center',
        justifyContent: 'center',
        height: '7.5%'
    },
    textTitleFooter: {
        fontSize: 20,
        fontWeight: 'bold'
    },
    textFooter: {
        color: '#FFF',
        fontSize: 16,
        fontFamily: 'Montserrat',
    },
    buttonNext: {
        borderColor: '#FFF',
        borderRadius: 100,
        backgroundColor: '#000',
        width: 100,
        height: 100,
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 4,
        position: 'absolute',
        right: 30,
        bottom: 50
    },
    letterShape: {
        position: 'absolute',
        left: 25,
        bottom: 20
    },
    letter: {
        position: 'absolute',
        bottom: 50,
        left: 70,
    },
    themeTitle: {
        fontFamily: 'Stora',
        fontSize: 40,
        color: '#FFFFFF',
        textAlign: 'center',
        top: 120
    },
    firstPlanShape: {
        position: 'absolute',
        zIndex: -1,
        top: '28%'
    },
    secondPlanShape: {
        position: 'absolute',
        zIndex: -2,
        top: '25%'
    },
    themeImage: {
        alignSelf: 'center',
        objectFit: 'contain',
        top: '18%'
    },

    //   BUTTONS COMPONENTS
    parametersButton:{
        position: 'absolute',
        right: 10,
        top: 40,
        zIndex: 1000,
      },
    closeButton:{
        position: 'absolute',
        top: 105,
        right: 10,
        width: 65,
        height: 65,
        zIndex:1001,
      },
    // Parameters MODAL
    modalContainerParam:{
        zIndex: 1000,
        position: 'relative',
    },
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'relative',
    },
    modalView: {
        backgroundColor: 'white',
        borderRadius: 25,
        backgroundColor: '#1C191FEA',
        borderColor: '#fff',
        alignItems: 'center',
        width: '91%',
        height:'90%',
        borderWidth: 3,
        
    },
    modalTitle1:{
        fontStyle: 'italic',
        color: '#979797A1',
        fontSize: 54,
        marginRight:'auto',
        marginLeft:21,
        marginTop:10,
        marginBottom:-14,
        fontWeight: '900',
    },
    modalTitle2: {
        textAlign: 'center',
        fontSize: 50,
        color: '#ffffff',
        marginBottom: 40,
        fontStyle: 'italic',
        fontWeight: '900',
    },

    closeModalParam: {
        width: 60,
        height: 60,
        position: 'absolute',
        right: 0,
        top:-34,
        right:-21,
        zIndex:10000,
    },

    // BUTTONS MODAL PARAMETERS
    buttonModalParam: {
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.22)',
        borderColor: '#fff',
        width: '86%',
        borderRadius: 15,
        borderWidth: 3,
        height:100,
        marginBottom: 30,
    },
    modalText:{
        fontSize: 34,
        color: '#ffffff',
        width: '90%',
        fontStyle: 'italic',
        textAlign:'left',
        fontStyle: 'italic',
        fontWeight:'900',
     },
     modalTextPremium:{
        color:'#FFE602',
        marginLeft:120,
        textShadowColor: 'rgba(255, 230, 2, 0.7)',
        textShadowOffset: { width: 1, height: 1 },
        textShadowRadius: 6,
        fontSize:36,
        
     },
     modalTextRules:{
        color:'#FF0000',
        textAlign:'center',
        textShadowColor: 'rgba(255, 0, 0, 0.7)',
        textShadowOffset: { width: 0, height: 0 },
        textShadowRadius: 3,
     },
     modalTextLanguages:{
        color:'#18D5FF',
        textAlign:'center',
        textShadowColor: 'rgba(24, 213, 255, 0.7)',
        textShadowOffset: { width: 0, height: 0 },
        textShadowRadius: 3,
     },
     modalTextSharing:{
        color:'#ffffff',
        textAlign:'center',
        textShadowColor: 'rgba(0, 0, 0, 0.7)',
        textShadowOffset: { width: 0, height: 0 },
        textShadowRadius: 3,
     },
    //  IMG Parameters MODAL
    logoPremium:{
        position: 'absolute',
        zIndex:100000,
        width:100,
        height:140,
        left:-40,
    },
    rulesLogo:{
        position: 'absolute',
        width:70,
        height:90,
        right:-30,
        top:-10,
    },
    sharingArrow:{
        position: 'absolute',
        width:55,
        height:60,
        left:-12,
        top:17,
    },
    flagsDropDown:{
        width: 50,
        height:30,
    },
    rulesStart:{
        position: 'absolute',
        top: 398,
        right: 10,
    },
    start:{
        position: 'relative',
    },
    wheelIcon:{
        position: 'absolute',
        left:150,
        top:26,
        zIndex: 1000,
        width:90,
        height:90,
    }
    
    
      
})

module.exports = componentsStyles