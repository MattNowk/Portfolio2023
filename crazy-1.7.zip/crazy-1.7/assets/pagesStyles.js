import { StyleSheet } from "react-native";

// HomePage Styles

const pagesStyles = StyleSheet.create({
    // CSS FOR RULES PAGE
    container: {
        flex: 1,
        position: 'relative',
      },
      logoRedCircle: {
        marginRight: 'auto',
        marginLeft: 'auto',
        marginTop: '-20%',
      },
      nextButton: {
        position: 'absolute',
        right: 0,
        top: 220,
        right: 75,
      },
      rulesSection: {
        display: 'flex',
        marginTop: 30,
        width: '82%',
        marginLeft: 'auto',
        marginRight: 'auto',
      },
      rulesTitle: {
        fontSize: 40,
        color: 'red',
        textAlign: 'center',
        marginBottom: 10,
      },
      rulesText: {
        textAlign: 'center',
        fontSize: 34,
        lineHeight: 38,
      },
      rulesText1: {
        marginBottom: 35,
      },
      rulesYellowCircle: {
        position: 'absolute',
        bottom: 0,
      },
    //   CSS FOR PLEDGE WHEEL PAGE
    containerWheel: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: '#E74C3C'
    },
    startButtonView: {
      position: 'absolute',
    },
    startButton: {
      backgroundColor: 'rgba(0,0,0,.5)',
      marginTop: 50,
      padding: 5,
    },
    startButtonText: {
      fontSize: 50,
      color: '#fff',
      fontWeight: 'bold',
    },
    winnerView: {
      position: 'absolute',
      justifyContent: 'center',
      alignItems: 'center',
    },
    tryAgainButton: {
      padding: 10,
    },
    winnerText: {
      fontSize: 30,
    },
    tryAgainButton: {
      padding: 5,
      backgroundColor: 'rgba(0,0,0,0.5)',
    },
    tryAgainText: {
      fontSize: 20,
      color: '#fff',
    },
    containerBlur:{
        position: 'absolute',
        top: 0,
        bottom: 0,
        left: 0,
        right: 0,
        width:'100%',
        height:"100%",
        backgroundColor: 'black',
        opacity: 0.7,
        zIndex:1000,
    },
    });


module.exports = pagesStyles;