import { StyleSheet } from "react-native";

const globalStyles = StyleSheet.create({
    primaryColor: {
        backgroundColor: '#FFE602'
    },
    secondaryColor: {
        backgroundColor: '#FF0000'
    },
    primaryFont: {
        fontFamily: 'Montserrat'
    },
    secondaryFont: {
        fontFamily: 'Stora'
    }
})

module.exports = globalStyles;