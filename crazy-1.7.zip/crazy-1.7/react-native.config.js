module.exports = {
    project:  {
        android: {},
        ios: {},
    },
    assets: ["./assets/fonts/"]
}