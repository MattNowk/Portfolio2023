import Rules from './pages/Rules';
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import FirstPage from './pages/FirstPage';
import Game from './pages/Game';
import Home from './pages/Home';
import { useFonts } from 'expo-font';
import { useState } from 'react';
import SecondPage from './pages/SecondPage';


export default function App() {
     
  const [modalVisible, setModalVisible] = useState(false);

  const [fontsLoaded] = useFonts({
    'Stora': require('./assets/fonts/stora/Stora.ttf'),
    'Montserrat': require('./assets/fonts/montserrat/Montserrat-Regular.ttf')
  })

  if (!fontsLoaded) {
    return null;
  }
  
  const Stack = createStackNavigator();

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="FirstPage">
        {/* <Stack.Screen name="Rules" options={{ headerShown: false }}>
          {props => <Rules {...props} modalVisible={modalVisible} setModalVisible={setModalVisible} selectedLanguage={selectedLanguage}  setSelectedLanguage={setSelectedLanguage}/>}
  </Stack.Screen> */}
        <Stack.Screen
          name="FirstPage"
          component={FirstPage}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="Home"
          component={Home}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="SecondPage"
          component={SecondPage}
          options={{ headerShown: false }}
        />
<Stack.Screen name="Rules" component={Rules} options={{ headerShown: false }} />
        <Stack.Screen
        name="Game"
        component={Game}
        options={{ headerShown: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}