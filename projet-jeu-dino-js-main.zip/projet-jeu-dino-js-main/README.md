# Projet Jeu Dino JS



## Consignes

Dans ce jeu saint et bien entendu tout public ^^' essayé de grimper les niveaux ! 



Attention au bout de 1000 pas le jeu s'intensifie ! 

## Vraies consignes 

Entr€z 3n #nf€# 



vous n'arriverais pas à atteindre le level max des 11000 pas.

## Le contenu 

J'ai essayé de mettre un max de commentaire pour que mon code sois lisible

Bon jeu ! 