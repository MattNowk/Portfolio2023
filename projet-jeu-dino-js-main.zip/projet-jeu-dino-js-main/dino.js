var dino = document.getElementById("dino"); /*Chercher dans le HTML le dino*/
var cactus = document.getElementById("cactus"); /*Chercher dans le HTML le cactus*/
var score = document.getElementById("score"); /*Chercher dans le HTML le score*/
var compteur = 0; /*Compteur*/

var son = new Audio(); /*Ajout du son du sang*/
son.src = "blood.mp3";

var hell_theme = new Audio(); /*Ajout du son du theme*/
hell_theme.src = "Hell.mp3";
hell_theme.volume = 0.5;

function sauter() { /*Ajout du son du saut*/
    dino.classList.add('saut');
    setTimeout(() => {                      
        dino.classList.remove('saut');
    }, 500);
}


document.addEventListener('keypress', () => { /*Quand touche quelconque préssé = saut*/
    if (!dino.classList.contains('saut')){
        sauter();
    }
});

function mort() { /*Fonction mort*/
    dino.removeAttribute('dino');
    dino.style.backgroundImage = "url('Sprites/Blood.gif')";
    son.play();
    setTimeout(() => {
        alert("Vous avec un score de :" + score.innerText +
            "\n\nVoulez vous rejouer ?");
            location.reload();
    }, 20);
}


setInterval(() => { /*Interval qui va tout calculer pour la mort ou non du joueur*/
    var dinoTop = parseInt(window.getComputedStyle(dino)
    .getPropertyValue('top')); /*Chercher le Top du dino*/
    var CactusGauche = parseInt(window.getComputedStyle(cactus)
    .getPropertyValue('left')); /*Chercher le Left du cactus*/
    score.innerText++; /*Score qui augmente en fonction de l'interval*/
    compteur = score.innerText /*Compteur prend la valeur du score (pour qu'il soit retranscrit autre part)*/
    if(compteur > 1000){ /*Ajout de l'enfer au bout de 1000 pas */
        document.getElementById("jeu").style.backgroundImage = "url('Sprites/HELL.png')";
        document.getElementById("jeu").style.backgroundPosition = "center";
        cactus.style.backgroundImage = "url('Sprites/Monster.png')";
        cactus.style.animation = "cactus 1.1s infinite linear";
        hell_theme.play();  
        
    }
    if (compteur > 2000){ /*Augmente le challenge*/
        cactus.style.animation = "cactus 1s infinite linear";
    }
    if (compteur > 3000){ /*Augmente le challenge*/
        cactus.style.animation = "cactus 0.9s infinite linear";
    }
    if (compteur > 4000){ /*Augmente le challenge*/
        cactus.style.animation = "cactus 0.85s infinite linear";
    }
    if (compteur > 5000){ /*Augmente le challenge*/
        cactus.style.animation = "cactus 0.8s infinite linear";
    }
    if (compteur > 6000){ /*Augmente le challenge*/
        cactus.style.animation = "cactus 0.75s infinite linear";
    }
    if (compteur > 7000){ /*Augmente le challenge*/
        cactus.style.animation = "cactus 0.7s infinite linear";
    }
    if (compteur > 8000){ /*Augmente le challenge*/
        cactus.style.animation = "cactus 0.65s infinite linear";
    }
    if (compteur > 9000){ /*Augmente le challenge*/
        cactus.style.animation = "cactus 0.6s infinite linear";
    }
    if (compteur > 10000){ /*Augmente le challenge*/
        cactus.style.animation = "cactus 0.55s infinite linear";
    }
    if (compteur > 11000){ /*Augmente le challenge*/
        cactus.style.animation = "cactus 0.5s infinite linear";
    }
    if (compteur >= 11001){ /*Augmente le challenge*/
        alert("Bravo vous avez gagné !");
    }
    if (CactusGauche < 0) { /*Si le cactus sort du jeu*/
        cactus.style.display = 'none';
    } else {
        cactus.style.display = ''
    }
    if (CactusGauche < 40 && CactusGauche > 0 && dinoTop > 190) { /*Si le cactus et le dino rentre en collision*/
        mort();
    }
}, 25);
